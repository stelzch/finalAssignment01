package edu.kit.usxim.FinalAssignment1.exceptions;

public class GameException extends Exception {

    public GameException(String msg) {
        super(msg);
    }

}
